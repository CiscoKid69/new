#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Python API / v4yve.corp
# v4yve-api.py
# VK: https://vk.com/v4yve

# /IMPORTS/
from v4API.Errors import *
from v4API.Session import *